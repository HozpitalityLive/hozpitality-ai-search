"use client";

import * as React from "react";
import {
  Alert,
  Avatar,
  Box,
  Button,
  Chip,
  CircularProgress,
  Divider,
  IconButton,
  Link,
  Paper,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  AddRounded,
  ArrowUpwardRounded,
  AutoAwesomeRounded,
  ContentCopyRounded,
  DarkModeRounded,
  LightModeRounded,
  MenuRounded,
  OpenInNewRounded,
  RefreshRounded,
  SearchRounded,
  SmartToyRounded,
  StopRounded,
  WorkOutlineRounded,
} from "@mui/icons-material";
import ShapeGrid from "./ShapeGrid";
import {
  type ChatResponse,
  type SearchResult,
  type Table,
  type TurnView,
  emptyTurn,
  isSafeHttpUrl,
  isServerEvent,
  newConversationId,
  reduceEvent,
  reduceLegacyChunk,
  resultSubtitle,
  turnFromResponse,
} from "./chatProtocol";
import { looksLikeHtml, sanitizeHtml } from "./safeHtml";

type Role = "user" | "assistant";

type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  results?: SearchResult[];
  relatedResults?: SearchResult[];
  table?: Table;
  suggestions?: string[];
  loading?: boolean;
  error?: boolean;
  stopped?: boolean;
};

// AI search service (FastAPI). NEXT_PUBLIC_AI_V6_URL is still honoured so
// existing deployments keep working without new variables.
const API_URL = (
  process.env.NEXT_PUBLIC_AI_SEARCH_URL ||
  process.env.NEXT_PUBLIC_AI_V6_URL ||
  "https://llm.hozpitality.com"
).replace(/\/$/, "");

function getWebSocketUrl() {
  const configured = process.env.NEXT_PUBLIC_AI_SEARCH_WS_URL;
  if (configured) return configured;
  return API_URL.replace(/^http:/, "ws:").replace(/^https:/, "wss:") + "/chat/ws";
}

const CHAT_HTTP_URL = `${API_URL}/chat`;

const suggestions = [
  "Find chef jobs in Dubai",
  "Hotel companies in Dubai",
  "Articles about hotel technology",
  "Hospitality events in Dubai",
];

function uid(prefix = "id") {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function formatCell(value: unknown) {
  if (value === null || value === undefined || value === "") return "—";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

/** Raised when the WebSocket fails; `opened` tells whether a request was sent. */
class SocketError extends Error {
  constructor(
    message: string,
    public opened: boolean,
  ) {
    super(message);
  }
}

export default function HozpitalityAIChat() {
  const [messages, setMessages] = React.useState<ChatMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [sending, setSending] = React.useState(false);
  const [dark, setDark] = React.useState(true);
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [conversationId, setConversationId] = React.useState(() => newConversationId());
  const conversationRef = React.useRef(conversationId);
  const socketRef = React.useRef<WebSocket | null>(null);
  const abortRef = React.useRef<AbortController | null>(null);
  const stoppedRef = React.useRef(false);
  const bottomRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    conversationRef.current = conversationId;
  }, [conversationId]);

  React.useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  React.useEffect(() => {
    return () => {
      socketRef.current?.close(1000, "component-unmounted");
      socketRef.current = null;
      abortRef.current?.abort();
    };
  }, []);

  const sendMessage = React.useCallback(
    async (preset?: string) => {
      const message = (preset ?? input).trim();
      if (!message || sending) return;

      const assistantId = uid("assistant");
      setMessages((current) => [
        ...current,
        { id: uid("user"), role: "user", content: message },
        { id: assistantId, role: "assistant", content: "", loading: true },
      ]);
      setInput("");
      setSending(true);
      stoppedRef.current = false;

      const requestId = uid("req");
      let turn: TurnView = emptyTurn();

      const updateAssistant = (patch: Partial<ChatMessage>) => {
        setMessages((current) =>
          current.map((item) => (item.id === assistantId ? { ...item, ...patch } : item)),
        );
      };

      const show = (next: TurnView) => {
        turn = next;
        if (next.conversationId && next.conversationId !== conversationRef.current) {
          // Adopt the server's conversation id so follow-ups keep their memory.
          conversationRef.current = next.conversationId;
          setConversationId(next.conversationId);
        }
        updateAssistant({
          content: next.error && !next.content ? next.error : next.content,
          results: next.results.length ? next.results : undefined,
          relatedResults: next.relatedResults.length ? next.relatedResults : undefined,
          table: next.table,
          suggestions: next.suggestions,
          loading: !next.done && !stoppedRef.current,
          error: Boolean(next.error),
          stopped: next.stopped || stoppedRef.current,
        });
      };

      const runWebSocket = () =>
        new Promise<void>((resolve, reject) => {
          let settled = false;
          let opened = false;
          const resolveOnce = () => {
            if (!settled) {
              settled = true;
              resolve();
            }
          };
          const rejectOnce = (error: Error) => {
            if (!settled) {
              settled = true;
              reject(error);
            }
          };

          const socket = new WebSocket(getWebSocketUrl());
          socketRef.current = socket;

          // The request completes only on completion / error / stop / close,
          // never merely because the socket opened.
          socket.onopen = () => {
            opened = true;
            try {
              socket.send(
                JSON.stringify({
                  type: "chat",
                  message,
                  conversation_id: conversationRef.current,
                  request_id: requestId,
                  metadata: { client: "hozpitality-web", transport: "websocket" },
                }),
              );
            } catch (error) {
              rejectOnce(
                error instanceof Error ? error : new Error("Unable to send the AI request."),
              );
            }
          };

          socket.onmessage = (event) => {
            let data: unknown;
            try {
              data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
            } catch {
              if (typeof event.data === "string" && event.data.trim()) {
                show({ ...turn, content: turn.content + event.data });
              }
              return;
            }

            if (isServerEvent(data)) {
              show(reduceEvent(turn, data));
              if (data.type === "error") {
                rejectOnce(new Error(turn.error || "Unable to process the AI request."));
              } else if (data.type === "completion") {
                resolveOnce();
                socket.close(1000, "response-complete");
              }
              return;
            }

            // Legacy Vanna chunk format.
            const next = reduceLegacyChunk(turn, (data || {}) as Record<string, unknown>);
            show(next);
            if (next.done) {
              resolveOnce();
              socket.close(1000, "response-complete");
            }
          };

          socket.onerror = () => {
            rejectOnce(new SocketError("Unable to connect to Hozpitality AI.", opened));
          };

          socket.onclose = (event) => {
            if (socketRef.current === socket) socketRef.current = null;
            if (turn.done || stoppedRef.current) {
              resolveOnce();
              return;
            }
            rejectOnce(
              new SocketError(
                event.reason || `AI connection closed before the response completed (code ${event.code}).`,
                opened,
              ),
            );
          };
        });

      const runHttp = async () => {
        const controller = new AbortController();
        abortRef.current = controller;
        const response = await fetch(CHAT_HTTP_URL, {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Request-ID": requestId },
          body: JSON.stringify({ message, conversation_id: conversationRef.current }),
          signal: controller.signal,
        });
        if (!response.ok) {
          const detail = await response.json().catch(() => null);
          throw new Error(
            (detail && typeof detail.detail === "string" && detail.detail) ||
              `The AI service returned ${response.status}.`,
          );
        }
        show(turnFromResponse((await response.json()) as ChatResponse));
      };

      try {
        try {
          await runWebSocket();
        } catch (error) {
          // Fall back to HTTP only if the request never reached the server;
          // otherwise the turn may already be saved and must not run twice.
          if (error instanceof SocketError && !error.opened && !stoppedRef.current) {
            await runHttp();
          } else {
            throw error;
          }
        }
      } catch (error) {
        if (stoppedRef.current || (error instanceof DOMException && error.name === "AbortError")) {
          return;
        }
        updateAssistant({
          content:
            turn.content ||
            (error instanceof Error ? error.message : "Unable to connect to Hozpitality AI."),
          results: turn.results.length ? turn.results : undefined,
          relatedResults: turn.relatedResults.length ? turn.relatedResults : undefined,
          table: turn.table,
          loading: false,
          error: true,
        });
      } finally {
        if (socketRef.current?.readyState === WebSocket.OPEN && turn.done) {
          socketRef.current.close(1000, "request-finished");
        }
        abortRef.current = null;
        setSending(false);
      }
    },
    [input, sending],
  );

  const stopGeneration = () => {
    stoppedRef.current = true;
    const socket = socketRef.current;
    if (socket && socket.readyState === WebSocket.OPEN) {
      // Ask the server to stop; it still saves the turn (with a complete,
      // deterministic answer) so the conversation memory stays consistent.
      try {
        socket.send(JSON.stringify({ type: "stop" }));
      } catch {
        /* socket already closing */
      }
      window.setTimeout(() => socket.close(1000, "user-stopped"), 1500);
    }
    abortRef.current?.abort();

    setMessages((current) =>
      current.map((item) =>
        item.loading
          ? {
              ...item,
              content: item.content || "Generation stopped.",
              loading: false,
              stopped: true,
            }
          : item,
      ),
    );

    setSending(false);
  };

  const newChat = () => {
    stopGeneration();
    socketRef.current = null;
    setMessages([]);
    setInput("");
    const id = newConversationId();
    conversationRef.current = id;
    setConversationId(id);
  };

  const copyMessage = async (text: string) => {
    await navigator.clipboard?.writeText(text);
  };

  const colors = dark
    ? {
        bg: "#070A10",
        panel: "rgba(16, 21, 31, 0.82)",
        panelSolid: "#10151F",
        border: "rgba(148, 163, 184, 0.13)",
        text: "#F8FAFC",
        muted: "#94A3B8",
        accent: "#6D5EF7",
        accent2: "#22D3EE",
        user: "#171D2A",
      }
    : {
        bg: "#F6F8FC",
        panel: "rgba(255,255,255,0.88)",
        panelSolid: "#FFFFFF",
        border: "rgba(15, 23, 42, 0.10)",
        text: "#101828",
        muted: "#667085",
        accent: "#5B4CF0",
        accent2: "#0891B2",
        user: "#EEF2FF",
      };

  const lastAssistantId = [...messages].reverse().find((m) => m.role === "assistant")?.id;

  return (
    <>
      <Box
        sx={{
          minHeight: "100vh",
          backgroundColor: colors.bg,
          color: colors.text,
          position: "relative",
          overflow: "hidden",
          isolation: "isolate",
          "&::before": {
            content: '""',
            position: "fixed",
            width: 520,
            height: 520,
            top: -260,
            right: -160,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${colors.accent}25 0%, transparent 68%)`,
            pointerEvents: "none",
          },
          "&::after": {
            content: '""',
            position: "fixed",
            width: 420,
            height: 420,
            bottom: -240,
            left: -180,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${colors.accent2}14 0%, transparent 68%)`,
            pointerEvents: "none",
          },
        }}
      >
        {/* FULL CHAT SHAPE GRID BACKGROUND — BELOW HEADER */}
        <Box
          sx={{
            position: "fixed",
            top: 72,
            left: 0,
            right: 0,
            bottom: 0,
            width: "100%",
            height: "calc(100vh - 72px)",
            zIndex: 0,
            pointerEvents: "none",
            overflow: "hidden",
            opacity: dark ? 0.85 : 0.25,
          }}
        >
          <Box
            sx={{
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              minHeight: "calc(100vh - 72px)",
            }}
          >
            <ShapeGrid
              speed={0.13}
              squareSize={30}
              direction="diagonal"
              borderColor={dark ? "#394354" : "#94A3B8"}
              hoverFillColor={dark ? "#1E293B" : "#E2E8F0"}
              hoverTrailAmount={9}
              shape="hexagon"
            />
          </Box>
        </Box>
        {/* Header */}
        <Box
          sx={{
            height: 72,
            px: { xs: 2, md: 4 },
            borderBottom: `1px solid ${colors.border}`,
            background: dark ? "rgba(16, 21, 31, 0.94)" : "rgba(255, 255, 255, 0.94)",
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            position: "sticky",
            top: 0,
            zIndex: 20,
          }}
        >
          <Stack direction="row" alignItems="center" spacing={1.5}>
            <IconButton
              onClick={() => setDrawerOpen((v) => !v)}
              sx={{ color: colors.text, display: { md: "none" } }}
              aria-label="Open menu"
            >
              <MenuRounded />
            </IconButton>

            <Avatar
              sx={{
                width: 40,
                height: 40,
                bgcolor: colors.accent,
                boxShadow: `0 0 30px ${colors.accent}55`,
              }}
            >
              <AutoAwesomeRounded fontSize="small" />
            </Avatar>

            <Box>
              <Typography fontWeight={800} fontSize={16}>
                Hozpitality AI
              </Typography>
              <Stack direction="row" spacing={0.7} alignItems="center">
                <Box
                  sx={{
                    width: 7,
                    height: 7,
                    borderRadius: "50%",
                    bgcolor: "#22C55E",
                    boxShadow: "0 0 10px #22C55E",
                  }}
                />
                <Typography fontSize={11} color={colors.muted}>
                  AI Search
                </Typography>
              </Stack>
            </Box>
          </Stack>

          <Stack direction="row" spacing={0.5}>
            <Tooltip title="New conversation">
              <IconButton onClick={newChat} sx={{ color: colors.muted }} aria-label="New conversation">
                <AddRounded />
              </IconButton>
            </Tooltip>
            <Tooltip title={dark ? "Light mode" : "Dark mode"}>
              <IconButton
                onClick={() => setDark((v) => !v)}
                sx={{ color: colors.muted }}
                aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
              >
                {dark ? <LightModeRounded /> : <DarkModeRounded />}
              </IconButton>
            </Tooltip>
          </Stack>
        </Box>

        <Box
          sx={{
            width: "100%",
            maxWidth: 1180,
            mx: "auto",
            px: { xs: 1.5, sm: 3 },
            py: { xs: 2, md: 4 },
            position: "relative",
            zIndex: 1,
          }}
        >
          {/* Intro */}
          {messages.length === 0 && (
            <Box
              sx={{
                minHeight: "calc(100vh - 160px)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Box sx={{ width: "100%", maxWidth: 850 }}>
                <Stack alignItems="center" spacing={2.2} sx={{ mb: 4 }}>
                  <Box
                    sx={{
                      width: 68,
                      height: 68,
                      borderRadius: "22px",
                      display: "grid",
                      placeItems: "center",
                      background: `linear-gradient(135deg, ${colors.accent}, ${colors.accent2})`,
                      boxShadow: `0 20px 70px ${colors.accent}35`,
                    }}
                  >
                    <SmartToyRounded sx={{ fontSize: 34, color: "#fff" }} />
                  </Box>

                  <Typography
                    component="h1"
                    sx={{
                      color: dark ? "white" : "black",
                      fontSize: { xs: 30, md: 46 },
                      lineHeight: 1.05,
                      fontWeight: 850,
                      letterSpacing: "-0.045em",
                      textAlign: "center",
                    }}
                  >
                    What can I help you{" "}
                    <Box
                      component="span"
                      sx={{
                        background: `linear-gradient(90deg, ${colors.accent}, ${colors.accent2})`,
                        backgroundClip: "text",
                        WebkitBackgroundClip: "text",
                        color: "transparent",
                      }}
                    >
                      find?
                    </Box>
                  </Typography>

                  <Typography
                    sx={{
                      color: colors.muted,
                      textAlign: "center",
                      maxWidth: 620,
                      fontSize: { xs: 14, md: 16 },
                      lineHeight: 1.7,
                    }}
                  >
                    Search Hozpitality jobs, professionals, companies, products, articles,
                    events, awards and FAQs using natural language — then refine, ask for
                    more, or compare results.
                  </Typography>
                </Stack>

                <Composer
                  input={input}
                  setInput={setInput}
                  sending={sending}
                  colors={colors}
                  onSend={() => sendMessage()}
                  onStop={stopGeneration}
                />

                <Stack
                  direction="row"
                  flexWrap="wrap"
                  justifyContent="center"
                  gap={1}
                  sx={{ mt: 2 }}
                >
                  {suggestions.map((item) => (
                    <Chip
                      key={item}
                      label={item}
                      onClick={() => sendMessage(item)}
                      icon={<SearchRounded sx={{ fontSize: 16 }} />}
                      sx={{
                        color: colors.muted,
                        bgcolor: colors.panel,
                        border: `1px solid ${colors.border}`,
                        backdropFilter: "blur(12px)",
                        "&:hover": {
                          color: colors.text,
                          borderColor: `${colors.accent}66`,
                          bgcolor: `${colors.accent}12`,
                        },
                      }}
                    />
                  ))}
                </Stack>
              </Box>
            </Box>
          )}

          {/* Conversation */}
          {messages.length > 0 && (
            <Box sx={{ maxWidth: 900, mx: "auto", pb: 18 }}>
              <Stack spacing={2.5}>
                {messages.map((message, index) => (
                  <MessageBubble
                    key={message.id}
                    message={message}
                    colors={colors}
                    onCopy={copyMessage}
                    showSuggestions={message.id === lastAssistantId && !sending}
                    onSuggestion={(text) => sendMessage(text)}
                    onRetry={() => {
                      const previousUser = messages
                        .slice(0, index)
                        .reverse()
                        .find((m) => m.role === "user");
                      if (previousUser) sendMessage(previousUser.content);
                    }}
                  />
                ))}
                <div ref={bottomRef} />
              </Stack>
            </Box>
          )}

          {/* Composer */}
          {messages.length > 0 && (
            <Box
              sx={{
                position: "fixed",
                left: 0,
                right: 0,
                bottom: 0,
                px: { xs: 1.5, sm: 3 },
                pb: { xs: 1.5, md: 2.5 },
                pt: 1,
                background: `linear-gradient(180deg, transparent, ${colors.bg} 28%)`,
                zIndex: 15,
              }}
            >
              <Box sx={{ maxWidth: 900, mx: "auto" }}>
                <Composer
                  input={input}
                  setInput={setInput}
                  sending={sending}
                  colors={colors}
                  onSend={() => sendMessage()}
                  onStop={stopGeneration}
                />
                <Typography
                  sx={{
                    textAlign: "center",
                    color: colors.muted,
                    opacity: 0.65,
                    fontSize: 10,
                    mt: 0.8,
                  }}
                >
                  Results come from Hozpitality listings. Hozpitality AI can make mistakes in
                  summaries — verify important information on the listing.
                </Typography>
              </Box>
            </Box>
          )}
        </Box>

        {/* Mobile side hint */}
        {drawerOpen && (
          <Box
            onClick={() => setDrawerOpen(false)}
            sx={{
              position: "fixed",
              inset: 0,
              zIndex: 30,
              bgcolor: "rgba(0,0,0,.45)",
              display: { md: "none" },
            }}
          >
            <Paper
              onClick={(e) => e.stopPropagation()}
              sx={{
                width: 290,
                height: "100%",
                p: 2.5,
                bgcolor: colors.panelSolid,
                color: colors.text,
                borderRadius: 0,
              }}
            >
              <Stack spacing={2}>
                <Typography fontWeight={800}>Hozpitality AI</Typography>
                <Divider sx={{ borderColor: colors.border }} />
                <Button
                  startIcon={<AddRounded />}
                  onClick={newChat}
                  sx={{ justifyContent: "flex-start", color: colors.text }}
                >
                  New conversation
                </Button>
                <Button
                  startIcon={<WorkOutlineRounded />}
                  onClick={() => sendMessage("Find chef jobs in Dubai")}
                  sx={{ justifyContent: "flex-start", color: colors.text }}
                >
                  Browse jobs
                </Button>
              </Stack>
            </Paper>
          </Box>
        )}
      </Box>
    </>
  );
}

function Composer({
  input,
  setInput,
  sending,
  colors,
  onSend,
  onStop,
}: {
  input: string;
  setInput: (value: string) => void;
  sending: boolean;
  colors: Record<string, string>;
  onSend: () => void;
  onStop: () => void;
}) {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 1,
        pl: 2,
        borderRadius: "20px",
        bgcolor: colors.panel,
        border: `1px solid ${colors.border}`,
        backdropFilter: "blur(22px)",
        boxShadow: "0 18px 70px rgba(0,0,0,.16)",
        display: "flex",
        alignItems: "flex-end",
        gap: 1,
      }}
    >
      <TextField
        fullWidth
        multiline
        maxRows={5}
        placeholder="Ask anything about Hozpitality..."
        value={input}
        onChange={(e) => setInput(e.target.value.slice(0, 2000))}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            onSend();
          }
        }}
        variant="standard"
        inputProps={{ maxLength: 2000, "aria-label": "Message" }}
        InputProps={{
          disableUnderline: true,
          sx: {
            color: colors.text,
            fontSize: 15,
            py: 1,
            "& textarea::placeholder": {
              color: colors.muted,
              opacity: 1,
            },
          },
        }}
      />

      <IconButton
        onClick={sending ? onStop : onSend}
        disabled={!sending && !input.trim()}
        aria-label={sending ? "Stop generating" : "Send message"}
        sx={{
          flex: "0 0 auto",
          width: 46,
          height: 46,
          borderRadius: "15px",
          color: "#fff",
          bgcolor: sending ? "#EF4444" : colors.accent,
          "&:hover": {
            bgcolor: sending ? "#DC2626" : colors.accent,
            transform: "translateY(-1px)",
          },
          "&.Mui-disabled": {
            color: colors.muted,
            bgcolor: `${colors.muted}18`,
          },
        }}
      >
        {sending ? <StopRounded /> : <ArrowUpwardRounded />}
      </IconButton>
    </Paper>
  );
}

/** Plain text with **bold** support; sanitized HTML only for legacy content. */
function RichText({ text, colors, error }: { text: string; colors: Record<string, string>; error?: boolean }) {
  const sx = {
    whiteSpace: "pre-wrap",
    lineHeight: 1.7,
    fontSize: 14.5,
    color: error ? "#FCA5A5" : colors.text,
    "& a": { color: colors.accent2 },
    "& img": { maxWidth: "100%", borderRadius: 1 },
  } as const;

  if (looksLikeHtml(text)) {
    return <Typography component="div" sx={sx} dangerouslySetInnerHTML={{ __html: sanitizeHtml(text) }} />;
  }
  const parts = text.split(/(\*\*[^*\n]+\*\*)/g);
  return (
    <Typography component="div" sx={sx}>
      {parts.map((part, i) =>
        part.startsWith("**") && part.endsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : part,
      )}
    </Typography>
  );
}

/** Concise inline references: "1. Title / Company · City / View here". */
function ResultList({
  results,
  colors,
}: {
  results: SearchResult[];
  colors: Record<string, string>;
}) {
  const mixedTypes = new Set(results.map((r) => r.entity_type)).size > 1;
  return (
    <Box component="ol" sx={{ listStyle: "none", p: 0, m: 0 }}>
      {results.slice(0, 10).map((result, index) => {
        const number = result.number ?? index + 1;
        const url = isSafeHttpUrl(result.url) ? result.url : null;
        const image = isSafeHttpUrl(result.image) ? result.image : null;
        const subtitle = resultSubtitle(result);
        return (
          <Box
            component="li"
            key={`${result.entity_type}:${result.entity_id}:${index}`}
            sx={{
              display: "flex",
              alignItems: "flex-start",
              gap: 1.2,
              py: 1.1,
              borderTop: index ? `1px solid ${colors.border}` : "none",
            }}
          >
            <Typography sx={{ minWidth: 22, color: colors.muted, fontWeight: 700, fontSize: 14 }}>
              {number}.
            </Typography>
            {image && (
              <Box
                component="img"
                src={image}
                alt=""
                loading="lazy"
                referrerPolicy="no-referrer"
                sx={{ width: 40, height: 40, borderRadius: 1.5, objectFit: "cover", flex: "0 0 auto" }}
              />
            )}
            <Box sx={{ minWidth: 0, flex: 1 }}>
              <Typography fontWeight={700} fontSize={14} sx={{ wordBreak: "break-word" }}>
                {result.title}
                {mixedTypes && (
                  <Typography component="span" fontSize={11} color={colors.muted} sx={{ ml: 0.8 }}>
                    {String(result.entity_type).toUpperCase()}
                  </Typography>
                )}
              </Typography>
              {subtitle && (
                <Typography fontSize={12.5} color={colors.muted}>
                  {subtitle}
                </Typography>
              )}
              {url && (
                <Link
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  underline="hover"
                  sx={{
                    fontSize: 12.5,
                    fontFamily: (theme) => theme.typography.fontFamily,
                    color: colors.accent2,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 0.4,
                  }}
                >
                  View here <OpenInNewRounded sx={{ fontSize: 13 }} />
                </Link>
              )}
            </Box>
          </Box>
        );
      })}
    </Box>
  );
}

function MessageBubble({
  message,
  colors,
  onCopy,
  onSuggestion,
  onRetry,
  showSuggestions,
}: {
  message: ChatMessage;
  colors: Record<string, string>;
  onCopy: (text: string) => void;
  onSuggestion: (text: string) => void;
  onRetry: () => void;
  showSuggestions: boolean;
}) {
  const isUser = message.role === "user";
  const hasResults = Boolean(message.results?.length || message.relatedResults?.length);

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: isUser ? "flex-end" : "flex-start",
        gap: 1.2,
      }}
    >
      {!isUser && (
        <Avatar
          sx={{
            width: 34,
            height: 34,
            flex: "0 0 auto",
            bgcolor: `${colors.accent}20`,
            color: colors.accent2,
            border: `1px solid ${colors.accent}30`,
          }}
        >
          <AutoAwesomeRounded sx={{ fontSize: 18 }} />
        </Avatar>
      )}

      <Box sx={{ maxWidth: { xs: "88%", sm: "78%" }, minWidth: 0 }}>
        <Paper
          elevation={0}
          sx={{
            px: { xs: 1.8, sm: 2.2 },
            py: 1.7,
            borderRadius: isUser ? "20px 20px 5px 20px" : "5px 20px 20px 20px",
            bgcolor: isUser ? colors.user : colors.panel,
            border: `1px solid ${colors.border}`,
            color: colors.text,
            backdropFilter: "blur(18px)",
          }}
        >
          {message.loading && !message.content ? (
            <Stack direction="row" spacing={1} alignItems="center">
              <CircularProgress size={15} sx={{ color: colors.accent2 }} />
              <Typography color={colors.muted} fontSize={14}>
                {hasResults ? "Writing the answer..." : "Searching Hozpitality..."}
              </Typography>
            </Stack>
          ) : (
            <RichText text={message.content} colors={colors} error={message.error} />
          )}

          {message.results && message.results.length > 0 && (
            <Box sx={{ mt: 1.2 }}>
              <ResultList results={message.results} colors={colors} />
            </Box>
          )}

          {message.relatedResults && message.relatedResults.length > 0 && (
            <Box sx={{ mt: 1.4 }}>
              <Alert
                severity="info"
                variant="outlined"
                sx={{ py: 0, mb: 0.6, fontSize: 12.5, color: colors.muted, borderColor: colors.border }}
              >
                Related results — these are not exact matches for your request.
              </Alert>
              <ResultList results={message.relatedResults} colors={colors} />
            </Box>
          )}

          {message.table && (
            <Paper
              elevation={0}
              sx={{
                mt: 1.2,
                overflow: "auto",
                borderRadius: "16px",
                bgcolor: "transparent",
                border: `1px solid ${colors.border}`,
              }}
            >
              <Box
                component="table"
                sx={{
                  width: "100%",
                  borderCollapse: "collapse",
                  minWidth: 480,
                  fontFamily: (theme) => theme.typography.fontFamily,
                }}
              >
                <Box component="thead">
                  <Box component="tr">
                    {message.table.columns.map((column) => (
                      <Box
                        component="th"
                        key={column}
                        sx={{
                          p: 1.2,
                          textAlign: "left",
                          fontSize: 11,
                          color: colors.muted,
                          borderBottom: `1px solid ${colors.border}`,
                          whiteSpace: "nowrap",
                        }}
                      >
                        {column}
                      </Box>
                    ))}
                  </Box>
                </Box>
                <Box component="tbody">
                  {message.table.rows.slice(0, 50).map((row, rowIndex) => (
                    <Box component="tr" key={rowIndex}>
                      {row.map((value, cellIndex) => (
                        <Box
                          component="td"
                          key={cellIndex}
                          sx={{
                            p: 1.2,
                            fontSize: 12,
                            borderBottom: `1px solid ${colors.border}`,
                            color: colors.text,
                            fontWeight: cellIndex === 0 ? 700 : 400,
                          }}
                        >
                          {formatCell(value)}
                        </Box>
                      ))}
                    </Box>
                  ))}
                </Box>
              </Box>
            </Paper>
          )}
        </Paper>

        {!isUser && message.content && !message.loading && (
          <Stack direction="row" spacing={0.2} sx={{ mt: 0.5, ml: 0.5 }}>
            <Tooltip title="Copy">
              <IconButton
                size="small"
                onClick={() => onCopy(message.content)}
                sx={{ color: colors.muted }}
                aria-label="Copy answer"
              >
                <ContentCopyRounded sx={{ fontSize: 15 }} />
              </IconButton>
            </Tooltip>
            <Tooltip title="Ask again">
              <IconButton size="small" onClick={onRetry} sx={{ color: colors.muted }} aria-label="Ask again">
                <RefreshRounded sx={{ fontSize: 15 }} />
              </IconButton>
            </Tooltip>
          </Stack>
        )}

        {!isUser && showSuggestions && !message.loading && message.suggestions && message.suggestions.length > 0 && (
          <Stack direction="row" flexWrap="wrap" gap={0.8} sx={{ mt: 1, ml: 0.5 }}>
            {message.suggestions.map((item) => (
              <Chip
                key={item}
                label={item}
                size="small"
                onClick={() => onSuggestion(item)}
                sx={{
                  color: colors.muted,
                  bgcolor: colors.panel,
                  border: `1px solid ${colors.border}`,
                  "&:hover": { color: colors.text, borderColor: `${colors.accent}66` },
                }}
              />
            ))}
          </Stack>
        )}
      </Box>
    </Box>
  );
}
