/**
 * Allowlist HTML sanitizer for assistant content.
 *
 * The AI search backend returns structured data and plain text; this exists
 * for legacy/HTML responses. Only <a> and <img> survive, with a small set of
 * attributes and http(s) URLs only. Every other element is unwrapped to its
 * text; dangerous containers (script, style, iframe, svg, ...) are dropped
 * with their content. Output is produced by DOM serialization, so text is
 * always escaped.
 */

const ALLOWED: Record<string, string[]> = {
  A: ["href", "title"],
  IMG: ["src", "alt", "title", "width", "height"],
};

const DROP_WITH_CONTENT = new Set([
  "SCRIPT", "STYLE", "IFRAME", "FRAME", "OBJECT", "EMBED", "TEMPLATE", "NOSCRIPT",
  "SVG", "MATH", "LINK", "META", "BASE", "FORM", "INPUT", "BUTTON", "TEXTAREA", "SELECT",
]);

const BLOCK_BREAK = new Set(["P", "DIV", "LI", "TR", "H1", "H2", "H3", "H4", "H5", "H6"]);

function safeUrl(value: string | null): string | null {
  if (!value) return null;
  try {
    const url = new URL(value, "https://invalid.local");
    if (url.origin === "https://invalid.local") return null; // relative URLs are not allowed
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : null;
  } catch {
    return null;
  }
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function looksLikeHtml(value: string): boolean {
  return /<\/?[a-z][^>]*>/i.test(value);
}

export function sanitizeHtml(html: string): string {
  if (typeof window === "undefined" || typeof DOMParser === "undefined") {
    // Server render: no DOM available -> plain escaped text.
    return escapeHtml(html.replace(/<[^>]*>/g, " "));
  }
  const source = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
  const target = document.implementation.createHTMLDocument("");
  const out = target.createElement("div");

  const walk = (node: Node, parent: HTMLElement) => {
    node.childNodes.forEach((child) => {
      if (child.nodeType === Node.TEXT_NODE) {
        parent.appendChild(target.createTextNode(child.textContent || ""));
        return;
      }
      if (child.nodeType !== Node.ELEMENT_NODE) return;
      const element = child as Element;
      const tag = element.tagName.toUpperCase();
      if (DROP_WITH_CONTENT.has(tag)) return;

      if (tag === "BR") {
        parent.appendChild(target.createElement("br"));
        return;
      }
      const allowed = ALLOWED[tag];
      if (!allowed) {
        walk(element, parent); // unwrap
        if (BLOCK_BREAK.has(tag)) parent.appendChild(target.createElement("br"));
        return;
      }
      const clean = target.createElement(tag.toLowerCase());
      for (const name of allowed) {
        const value = element.getAttribute(name);
        if (value === null) continue;
        if (name === "href" || name === "src") {
          const url = safeUrl(value);
          if (url) clean.setAttribute(name, url);
        } else if (name === "width" || name === "height") {
          if (/^\d{1,4}$/.test(value)) clean.setAttribute(name, value);
        } else {
          clean.setAttribute(name, value.slice(0, 200));
        }
      }
      if (tag === "A") {
        if (!clean.getAttribute("href")) {
          walk(element, parent); // link without a safe URL -> plain text
          return;
        }
        clean.setAttribute("target", "_blank");
        clean.setAttribute("rel", "noopener noreferrer nofollow");
        walk(element, clean);
      } else if (tag === "IMG") {
        if (!clean.getAttribute("src")) return;
        clean.setAttribute("loading", "lazy");
        clean.setAttribute("referrerpolicy", "no-referrer");
      }
      parent.appendChild(clean);
    });
  };

  walk(source.body, out);
  return out.innerHTML;
}
