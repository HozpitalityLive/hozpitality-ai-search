/**
 * Hozpitality AI Search chat protocol (WebSocket /chat/ws, SSE /chat/stream,
 * HTTP POST /chat) plus the legacy Vanna chunk formats the UI already handled.
 *
 * Streaming events, in order:
 *   start -> results -> delta* -> final -> completion   (or error)
 *
 * Everything here is pure (no React, no DOM) so it can be unit-tested.
 */

export type EntityType =
  | "job"
  | "professional"
  | "company"
  | "product"
  | "article"
  | "event"
  | "award"
  | "faq";

export type SearchResult = {
  entity_type: EntityType | string;
  entity_id: string;
  title: string;
  snippet?: string | null;
  description?: string | null;
  company?: string | null;
  location?: {
    city?: string | null;
    country?: string | null;
  } | null;
  category?: string | null;
  url?: string | null;
  image?: string | null;
  number?: number | null;
};

export type Comparison = {
  columns: string[];
  rows: string[][];
};

export type ChatAction =
  | "search"
  | "clarify"
  | "more"
  | "compare"
  | "reset"
  | "detail"
  | "related_entity"
  | "smalltalk";

export type ChatResponse = {
  conversation_id: string;
  action: ChatAction;
  answer: string;
  results: SearchResult[];
  related_results: SearchResult[];
  message?: string | null;
  comparison?: Comparison | null;
  suggestions?: string[];
  state?: Record<string, unknown>;
  request_id?: string | null;
};

export type ServerEvent =
  | {
      type: "start";
      conversation_id: string;
      request_id?: string;
    }
  | {
      type: "results";
      conversation_id: string;
      data: Partial<ChatResponse>;
    }
  | {
      type: "delta";
      data: {
        text: string;
      };
    }
  | {
      type: "final";
      conversation_id: string;
      data: ChatResponse;
    }
  | {
      type: "completion";
      data?: {
        status?: "done" | "stopped";
      };
    }
  | {
      type: "error";
      data?: {
        message?: string;
        code?: number;
      };
    }
  | {
      type: "pong";
    };

export type Table = {
  columns: string[];
  rows: unknown[][];
};

/** Accumulated view of one assistant turn. */
export type TurnView = {
  content: string;
  results: SearchResult[];
  relatedResults: SearchResult[];
  notice?: string | null;
  table?: Table;
  suggestions: string[];
  action?: ChatAction;
  conversationId?: string;
  done: boolean;
  stopped: boolean;
  error?: string;

  /** true once `final` arrived: its answer is authoritative over streamed deltas */
  finalized: boolean;
};

export const emptyTurn = (): TurnView => ({
  content: "",
  results: [],
  relatedResults: [],
  suggestions: [],
  done: false,
  stopped: false,
  finalized: false,
});

function applyResponse(
  turn: TurnView,
  data: Partial<ChatResponse>,
): TurnView {
  const next: TurnView = { ...turn };

  if (Array.isArray(data.results)) {
    next.results = data.results;
  }

  if (Array.isArray(data.related_results)) {
    next.relatedResults = data.related_results;
  }

  if (data.message !== undefined) {
    next.notice = data.message;
  }

  if (Array.isArray(data.suggestions)) {
    next.suggestions = data.suggestions;
  }

  if (data.action) {
    next.action = data.action;
  }

  if (data.conversation_id) {
    next.conversationId = data.conversation_id;
  }

  if (
    data.comparison &&
    Array.isArray(data.comparison.columns) &&
    Array.isArray(data.comparison.rows)
  ) {
    next.table = {
      columns: data.comparison.columns,
      rows: data.comparison.rows,
    };
  }

  return next;
}

export function isServerEvent(value: unknown): value is ServerEvent {
  if (!value || typeof value !== "object") {
    return false;
  }

  const type = (value as { type?: unknown }).type;

  return (
    type === "start" ||
    type === "results" ||
    type === "delta" ||
    type === "final" ||
    type === "completion" ||
    type === "error" ||
    type === "pong"
  );
}

/** Reduce one streaming event into the turn view. */
export function reduceEvent(
  turn: TurnView,
  event: ServerEvent,
): TurnView {
  switch (event.type) {
    case "start":
      return {
        ...turn,
        conversationId:
          event.conversation_id || turn.conversationId,
      };

    case "results":
      return applyResponse(turn, event.data || {});

    case "delta":
      if (turn.finalized || turn.stopped) {
        return turn;
      }

      return {
        ...turn,
        content:
          turn.content + (event.data?.text || ""),
      };

    case "final": {
      const next = applyResponse(turn, event.data);

      return {
        ...next,
        content: event.data.answer || next.content,
        finalized: true,
      };
    }

    case "completion":
      return {
        ...turn,
        done: true,
        stopped:
          turn.stopped ||
          event.data?.status === "stopped",
      };

    case "error":
      return {
        ...turn,
        done: true,
        error:
          event.data?.message ||
          "Unable to process the AI request.",
      };

    default:
      return turn;
  }
}

/** Convert a non-streaming HTTP /chat response into a completed turn. */
export function turnFromResponse(
  response: ChatResponse,
): TurnView {
  const turn = applyResponse(
    emptyTurn(),
    response,
  );

  return {
    ...turn,
    content: response.answer,
    done: true,
    finalized: true,
  };
}

// ---------------------------------------------------------------------------
// Legacy Vanna chunk support
// Kept so the UI still works against /api/vanna
// ---------------------------------------------------------------------------

type LegacyRecord = Record<string, unknown>;

type LegacyChunk = LegacyRecord;

/**
 * Safely convert an unknown value into a record.
 */
function asRecord(
  value: unknown,
): LegacyRecord | null {
  if (
    value !== null &&
    typeof value === "object" &&
    !Array.isArray(value)
  ) {
    return value as LegacyRecord;
  }

  return null;
}

/**
 * Safely read a property from an unknown object.
 */
function getProperty(
  value: unknown,
  key: string,
): unknown {
  return asRecord(value)?.[key];
}

/**
 * Safely convert an unknown value to a string.
 */
function toNullableString(
  value: unknown,
): string | null {
  if (
    typeof value === "string" &&
    value.trim().length > 0
  ) {
    return value;
  }

  if (
    typeof value === "number" ||
    typeof value === "boolean"
  ) {
    return String(value);
  }

  return null;
}

export function getTextFromChunk(
  chunk: LegacyChunk,
): string {
  const simple = getProperty(chunk, "simple");
  const simpleData = getProperty(simple, "data");

  const rich = getProperty(chunk, "rich");
  const richData = getProperty(rich, "data");

  const data = getProperty(chunk, "data");

  const candidates: unknown[] = [
    getProperty(simpleData, "text"),
    getProperty(simple, "text"),

    getProperty(richData, "content"),
    getProperty(richData, "text"),

    getProperty(data, "content"),

    getProperty(chunk, "content"),
    getProperty(chunk, "message"),
  ];

  for (const value of candidates) {
    if (
      typeof value === "string" &&
      value.trim().length > 0
    ) {
      return value;
    }
  }

  return "";
}

export function getRowsFromChunk(
  chunk: LegacyChunk,
): Table | null {
  const rich = getProperty(chunk, "rich");
  const richData = getProperty(rich, "data");

  const directData = getProperty(chunk, "data");

  const data =
    asRecord(richData) ??
    asRecord(directData) ??
    {};

  const rows =
    data.rows ??
    data.data ??
    data.records;

  const columns =
    data.columns ??
    data.headers;

  if (!Array.isArray(rows) || rows.length === 0) {
    return null;
  }

  /*
   * Array-of-arrays:
   *
   * [
   *   ["John", "Dubai"],
   *   ["Mike", "Abu Dhabi"]
   * ]
   */
  if (Array.isArray(rows[0])) {
    return {
      columns: Array.isArray(columns)
        ? columns.map(String)
        : rows[0].map(
            (_: unknown, index: number) =>
              `Column ${index + 1}`,
          ),

      rows: rows.map((row: unknown[]) =>
        Array.isArray(row) ? row : [],
      ),
    };
  }

  /*
   * Array-of-objects:
   *
   * [
   *   { name: "John", city: "Dubai" },
   *   { name: "Mike", city: "Abu Dhabi" }
   * ]
   */
  if (
    typeof rows[0] === "object" &&
    rows[0] !== null &&
    !Array.isArray(rows[0])
  ) {
    const firstRow = rows[0] as Record<
      string,
      unknown
    >;

    const keys = Array.isArray(columns)
      ? columns.map(String)
      : Object.keys(firstRow);

    return {
      columns: keys,

      rows: rows.map((row: unknown) => {
        const record = asRecord(row);

        return keys.map(
          (key) => record?.[key],
        );
      }),
    };
  }

  return null;
}

/** Map legacy job items to the unified inline result format. */
export function getResultsFromChunk(
  chunk: LegacyChunk,
): SearchResult[] {
  const rich = getProperty(chunk, "rich");
  const richData = getProperty(rich, "data");

  const directData = getProperty(chunk, "data");

  const data =
    asRecord(richData) ??
    asRecord(directData) ??
    {};

  const items =
    data.items ??
    data.jobs ??
    data.results;

  if (!Array.isArray(items)) {
    return [];
  }

  return items
    .filter(
      (item: unknown) =>
        item !== null &&
        typeof item === "object" &&
        !Array.isArray(item),
    )
    .map(
      (
        item: unknown,
        index: number,
      ): SearchResult => {
        const record = asRecord(item) ?? {};

        const locationValue =
          record.location;

        const location =
          asRecord(locationValue);

        return {
          entity_type: String(
            record.entity_type ?? "job",
          ),

          entity_id: String(
            record.entity_id ??
              record.id ??
              index,
          ),

          title: String(
            record.title ??
              record.job_title ??
              "Hospitality opportunity",
          ),

          company: toNullableString(
            record.company ??
              record.company_name,
          ),

          location: {
            city: toNullableString(
              record.city ??
                record.job_city ??
                location?.city,
            ),

            country: toNullableString(
              record.country ??
                location?.country,
            ),
          },

          url: toNullableString(
            record.url ??
              record.job_link,
          ),

          image: toNullableString(
            record.image,
          ),

          snippet: toNullableString(
            record.snippet,
          ),

          description: toNullableString(
            record.description,
          ),

          category: toNullableString(
            record.category,
          ),

          number:
            typeof record.number === "number"
              ? record.number
              : null,
        };
      },
    );
}

/** Merge a legacy chunk (delta or accumulated text) into the turn. */
export function reduceLegacyChunk(
  turn: TurnView,
  chunk: LegacyChunk,
): TurnView {
  const next: TurnView = {
    ...turn,
  };

  const text = getTextFromChunk(chunk);

  if (text) {
    if (text.startsWith(next.content)) {
      next.content = text;
    } else if (!next.content.endsWith(text)) {
      next.content += text;
    }
  }

  const results = getResultsFromChunk(chunk);

  if (results.length) {
    next.results = [
      ...next.results,
      ...results,
    ];
  }

  const table = getRowsFromChunk(chunk);

  if (table) {
    next.table = table;
  }

  const chunkType = getProperty(
    chunk,
    "type",
  );

  const chunkData = getProperty(
    chunk,
    "data",
  );

  const chunkStatus = getProperty(
    chunkData,
    "status",
  );

  if (
    chunkType === "completion" ||
    chunkType === "done" ||
    chunkStatus === "done"
  ) {
    next.done = true;
  }

  return next;
}

// ---------------------------------------------------------------------------
// Presentation helpers
// ---------------------------------------------------------------------------

export function resultSubtitle(
  result: SearchResult,
): string {
  const parts = [
    result.company,
    result.location?.city ||
      result.location?.country,
  ].filter(
    (
      value,
    ): value is string =>
      typeof value === "string" &&
      value.trim().length > 0,
  );

  return parts.join(" · ");
}

export function isSafeHttpUrl(
  value: unknown,
): value is string {
  if (
    typeof value !== "string" ||
    !value.trim()
  ) {
    return false;
  }

  try {
    const url = new URL(value);

    return (
      url.protocol === "https:" ||
      url.protocol === "http:"
    );
  } catch {
    return false;
  }
}

export function newConversationId(): string {
  const cryptoApi = (
    globalThis as {
      crypto?: Crypto;
    }
  ).crypto;

  if (
    cryptoApi &&
    typeof cryptoApi.randomUUID === "function"
  ) {
    return cryptoApi.randomUUID();
  }

  return `conv-${Date.now()}-${Math.random()
    .toString(36)
    .slice(2, 12)}`;
}