/**
 * Protocol reducer tests. Run with Node's built-in runner after compiling,
 * e.g. `npx tsc chatProtocol.ts chatProtocol.test.ts --outDir /tmp/t --module commonjs
 * --target es2020 --lib es2020,dom && node --test /tmp/t/chatProtocol.test.js`.
 */
import assert from "node:assert/strict";
import { test } from "node:test";

import {
  type ChatResponse,
  type ServerEvent,
  emptyTurn,
  isSafeHttpUrl,
  isServerEvent,
  newConversationId,
  reduceEvent,
  reduceLegacyChunk,
  resultSubtitle,
  turnFromResponse,
} from "./chatProtocol";

const result = {
  entity_type: "job",
  entity_id: "101",
  title: "Executive Chef",
  company: "ABC Hospitality",
  location: { city: "Dubai", country: "United Arab Emirates" },
  url: "https://www.hozpitality.com/jobs/101",
  number: 1,
};

const final: ChatResponse = {
  conversation_id: "conv-12345678",
  action: "search",
  answer: "I found 1 chef job in Dubai.",
  results: [result],
  related_results: [],
  suggestions: ["Show me more"],
};

test("streaming events accumulate into a turn", () => {
  const events: ServerEvent[] = [
    { type: "start", conversation_id: "conv-12345678" },
    { type: "results", conversation_id: "conv-12345678", data: { results: [result], action: "search" } },
    { type: "delta", data: { text: "I found " } },
    { type: "delta", data: { text: "1 job." } },
  ];
  let turn = emptyTurn();
  for (const event of events) turn = reduceEvent(turn, event);
  assert.equal(turn.conversationId, "conv-12345678");
  assert.equal(turn.content, "I found 1 job.");
  assert.equal(turn.results.length, 1);
  assert.equal(turn.done, false);

  // The validated final answer replaces streamed text; late deltas are ignored.
  turn = reduceEvent(turn, { type: "final", conversation_id: "conv-12345678", data: final });
  turn = reduceEvent(turn, { type: "delta", data: { text: " extra" } });
  assert.equal(turn.content, "I found 1 chef job in Dubai.");
  assert.deepEqual(turn.suggestions, ["Show me more"]);
  turn = reduceEvent(turn, { type: "completion", data: { status: "done" } });
  assert.equal(turn.done, true);
  assert.equal(turn.stopped, false);
});

test("comparison becomes a table and related results stay separate", () => {
  const turn = reduceEvent(emptyTurn(), {
    type: "final",
    conversation_id: "c",
    data: {
      ...final,
      results: [],
      related_results: [result],
      comparison: { columns: ["Field", "#1 A", "#2 B"], rows: [["Company", "X", "Y"]] },
    },
  });
  assert.deepEqual(turn.table, { columns: ["Field", "#1 A", "#2 B"], rows: [["Company", "X", "Y"]] });
  assert.equal(turn.results.length, 0);
  assert.equal(turn.relatedResults.length, 1);
});

test("errors and stopped completions end the turn", () => {
  const errored = reduceEvent(emptyTurn(), { type: "error", data: { message: "busy", code: 409 } });
  assert.equal(errored.done, true);
  assert.equal(errored.error, "busy");
  const stopped = reduceEvent(emptyTurn(), { type: "completion", data: { status: "stopped" } });
  assert.equal(stopped.stopped, true);
});

test("HTTP fallback response maps to a finished turn", () => {
  const turn = turnFromResponse(final);
  assert.equal(turn.done, true);
  assert.equal(turn.content, final.answer);
  assert.equal(turn.results[0].title, "Executive Chef");
});

test("legacy Vanna chunks still work (delta and accumulated text, jobs, tables)", () => {
  let turn = emptyTurn();
  turn = reduceLegacyChunk(turn, { simple: { text: "Hello" } });
  turn = reduceLegacyChunk(turn, { simple: { text: "Hello world" } }); // accumulated
  turn = reduceLegacyChunk(turn, { simple: { text: "!" } }); // delta
  assert.equal(turn.content, "Hello world!");
  turn = reduceLegacyChunk(turn, { rich: { data: { jobs: [{ job_title: "Waiter", job_city: "Dubai", job_link: "https://x.com/1" }] } } });
  assert.equal(turn.results[0].title, "Waiter");
  assert.equal(turn.results[0].url, "https://x.com/1");
  turn = reduceLegacyChunk(turn, { rich: { data: { rows: [{ a: 1, b: 2 }] } } });
  assert.deepEqual(turn.table, { columns: ["a", "b"], rows: [[1, 2]] });
  assert.equal(reduceLegacyChunk(turn, { type: "completion" }).done, true);
});

test("event guard and helpers", () => {
  assert.equal(isServerEvent({ type: "delta", data: { text: "x" } }), true);
  assert.equal(isServerEvent({ simple: { text: "x" } }), false);
  assert.equal(resultSubtitle(result), "ABC Hospitality · Dubai");
  assert.equal(isSafeHttpUrl("https://www.hozpitality.com/jobs/1"), true);
  assert.equal(isSafeHttpUrl("javascript:alert(1)"), false);
  assert.equal(isSafeHttpUrl("executive-chef-1"), false);
  assert.match(newConversationId(), /^[A-Za-z0-9_-]{8,128}$/);
});
